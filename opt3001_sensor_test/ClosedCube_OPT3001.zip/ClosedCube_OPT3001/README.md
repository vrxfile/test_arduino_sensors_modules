ClosedCube Arduino Library for
ClosedCube OPT3001 Digital Ambient Light Sensor (ALS) with High Precision Human Eye Response Breakout 
=====================================================================================================

This is breakout board for [Texas Instruments OPT3001](http://www.ti.com/product/OPT3001) Digital Ambient Light Sensor (ALS) Sensor

[![](https://github.com/closedcube/ClosedCube_OPT3001_Arduino/blob/master/images/B060_OPT3001_Pic1.jpg)](https://www.tindie.com/stores/closedcube/)
[![](https://github.com/closedcube/ClosedCube_OPT3001_Arduino/blob/master/images/B060_OPT3001_Pic2.jpg)](https://www.tindie.com/stores/closedcube/)

### Where to Buy?

<a href="https://www.tindie.com/stores/closedcube/?ref=offsite_badges&utm_source=sellers_closedcube&utm_medium=badges&utm_campaign=badge_medium"><img src="https://d2ss6ovg47m0r5.cloudfront.net/badges/tindie-mediums.png" alt="I sell on Tindie" width="150" height="78"></a>


